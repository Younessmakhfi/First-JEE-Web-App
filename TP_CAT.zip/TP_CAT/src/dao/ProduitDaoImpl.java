package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import metier.entities.Produit;

public class ProduitDaoImpl implements IProduitDao {

	@Override
	public Produit save(Produit p) {
		Connection  connection = SingletonConnection.getConnetion();
		try {
			PreparedStatement ps = connection.prepareStatement
					("INSERT INTO produits (DESIGNATION,PRIX,QUANTITE) VALUES (?,?,?)");
			ps.setString(1, p.getDesignation());
			ps.setDouble(2, p.getPrix());
			ps.setInt(3, p.getQuantite());
			ps.executeUpdate();
			PreparedStatement ps2 = connection.prepareStatement
					("SELECT MAX(ID) AS MAX_ID FROM produits");
			ResultSet rs = ps2.executeQuery();
			if(rs.next()) {
				p.setId(rs.getLong("MAX_ID"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Produit> produitParMC(String MC) {
		List<Produit> produit = new ArrayList<Produit>();
		Connection  connection = SingletonConnection.getConnetion();
		try {
			PreparedStatement ps = connection.prepareStatement("SELECT * FROM produits WHERE Designation LIKE ?");
			ps.setString(1, MC);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				Produit p = new Produit();
				p.setId(rs.getLong("ID"));
				p.setDesignation(rs.getString("Designation"));
				p.setPrix(rs.getDouble("Prix"));
				p.setQuantite(rs.getInt("Quantite"));
				produit.add(p);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return produit;
	}

	@Override
	public Produit getProduit(Long id) {
		Produit p = new Produit();
		Connection  connection = SingletonConnection.getConnetion();
		try {
			PreparedStatement ps = connection.prepareStatement("SELECT * FROM produits WHERE ID=?");
			ps.setLong(1, id);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				
				p.setId(rs.getLong("ID"));
				p.setDesignation(rs.getString("Designation"));
				p.setPrix(rs.getDouble("Prix"));
				p.setQuantite(rs.getInt("Quantite"));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return p;
		
	}

	@Override
	public Produit update(Produit p) {
		Connection  connection = SingletonConnection.getConnetion();
		try {
			PreparedStatement ps = connection.prepareStatement
					("UPDATE produits SET DESIGNATION=?,PRIX=?,QUANTITE=? WHERE ID=?");
			ps.setString(1, p.getDesignation());
			ps.setDouble(2, p.getPrix());
			ps.setInt(3, p.getQuantite());
			ps.setLong(4,p.getId());
			ps.executeUpdate();
			ps.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return p;
		
	}

	@Override
	public void delete(Long id) {
	
		Connection  connection = SingletonConnection.getConnetion();
		try {
			PreparedStatement ps = connection.
					prepareStatement("DELETE FROM produits WHERE ID=?");
			ps.setLong(1, id);
			ps.executeUpdate();
			ps.close();	
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		
		
	}

}
