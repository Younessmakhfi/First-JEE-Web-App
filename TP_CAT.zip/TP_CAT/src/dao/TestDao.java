package dao;

import java.util.List;

import metier.entities.Produit;

public class TestDao {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ProduitDaoImpl dao = new ProduitDaoImpl();
		Produit p1 = dao.save(new Produit("PC gamer",200,20));
		Produit p2 = dao.save(new Produit("Imprimant",400,15));
		Produit p3 = dao.save(new Produit("Ordinateur portable",5000,100));
		Produit p4 = dao.save(new Produit("Optical Mouse 3.0",1340,5));
		List<Produit> produits = dao.produitParMC("% %");
		for(Produit p : produits) {
			System.out.println(p.getDesignation());
		}

	}

}
