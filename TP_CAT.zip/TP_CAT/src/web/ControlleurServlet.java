package web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.IProduitDao;
import dao.ProduitDaoImpl;
import metier.entities.Produit;
@WebServlet(name="cs",urlPatterns = {"*.php"})
public class ControlleurServlet extends HttpServlet{
	private IProduitDao metier;
@Override
public void init() throws ServletException {
	metier = new ProduitDaoImpl();
}

@Override
protected void doGet(HttpServletRequest req,
		HttpServletResponse resp) throws ServletException, IOException {
	String path = req.getServletPath();
	if(path.equals("/index.php")) {
		req.getRequestDispatcher("produits.jsp").forward(req, resp);
		}
	if(path.equals("/chercher.php")) {
		String motCle = req.getParameter("motCle");
		ProduitModel model= new ProduitModel();
		model.setMotCle(motCle);
		List<Produit> produits = metier.produitParMC("%"+motCle+"%");
		model.setPrduits(produits);
		req.setAttribute("model", model);
		
		req.getRequestDispatcher("produits.jsp").forward(req, resp);
		
		}
	if(path.equals("/Add.php")) {

		req.getRequestDispatcher("add.jsp").forward(req, resp);
		
		}
	if(path.equals("/delete.php")) {
		Long ID = Long.parseLong(req.getParameter("id")) ;
		ProduitModel model= new ProduitModel();
		metier.delete(ID);
		List<Produit> produits = metier.produitParMC("%%");
		req.setAttribute("model", model);
		//req.getRequestDispatcher("add.jsp").forward(req, resp);
		resp.sendRedirect("chercher.php?motCle=");
		//req.getRequestDispatcher("/chercher.php?motCle=").forward(req, resp);
		
		}
	if(path.equals("/edit.php")) {
		Long ID = Long.parseLong(req.getParameter("id")) ;
		Produit p = metier.getProduit(ID);
		req.setAttribute("p", p);
		//req.getRequestDispatcher("add.jsp").forward(req, resp);
		req.getRequestDispatcher("editProduit.jsp").forward(req, resp);
		
		}
	
	
	
}
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	String path = req.getServletPath();
	if(path.equals("/ajouterProduit.php")) {
		String designation = req.getParameter("designation");
		Double prix =Double.parseDouble(req.getParameter("prix")) ;
		int quantite =Integer.parseInt(req.getParameter("quantite"));
		Produit p = new Produit(designation,prix,quantite);
		metier.save(p);
		ProduitModel model= new ProduitModel();
		List<Produit> produits = metier.produitParMC("%%");
		model.setPrduits(produits);
		req.setAttribute("p", p);
		req.getRequestDispatcher("produitAjouter.jsp").forward(req, resp);
		
		}
	if(path.equals("/saveEditedProduct.php")) {
		Long ID = Long.parseLong(req.getParameter("id"));
		String designation = req.getParameter("designation");
		Double prix =Double.parseDouble(req.getParameter("prix")) ;
		int quantite =Integer.parseInt(req.getParameter("quantite"));
		Produit p = metier.getProduit(ID);
		p.setDesignation(designation);
		p.setPrix(prix);
		p.setQuantite(quantite);
		metier.update(p);
		//req.setAttribute("p", p);
		req.getRequestDispatcher("produits.jsp").forward(req, resp);
		//resp.sendRedirect("chercher.php?motCle=");
		
		}
	
	super.doPost(req, resp);
}
}
